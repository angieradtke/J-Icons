/**
 * Backward Compatibility — FontAwesome to SVG
 * Konvertiert alte <i class="fa ..."> zu SVG Icons
 */
(function() {
  'use strict';

  document.addEventListener('DOMContentLoaded', function() {
    convertFontAwesomeToSVG();
  });

  function convertFontAwesomeToSVG() {
    const faElements = document.querySelectorAll('i.fa, span.fa, i.fas, i.far, i.fab, span.fas, span.far, span.fab');

    faElements.forEach(element => {
      const classes = element.className;
      const iconInfo = parseIconClasses(classes);
      
      if (iconInfo.name) {
        const svg = createSVGIcon(iconInfo, classes);
        element.replaceWith(svg);
      }
    });
  }

  function parseIconClasses(classString) {
    const classes = classString.split(' ').filter(c => c);
    const info = {
      name: null,
      style: 'solid',
      size: '',
      spin: false,
      pulse: false,
      flip: '',
      rotate: 0,
      inverse: false,
      pullLeft: false,
      pullRight: false,
      border: false,
      fixedWidth: false,
      listItem: false,
    };

    for (const cls of classes) {
      if (cls.startsWith('fa-') && !cls.match(/^fa-(2|lg|xs|sm|1x|3x|4x|5x|6x|7x|8x|9x|10x)/)) {
        info.name = cls.substring(3);
      }

      if (cls === 'fa-solid' || cls === 'fas') {
        info.style = 'solid';
      } else if (cls === 'fa-regular' || cls === 'far') {
        info.style = 'regular';
      } else if (cls === 'fa-brands' || cls === 'fab') {
        info.style = 'brands';
      }

      if (cls.match(/^fa-(2x|lg|xs|sm|3x|4x|5x|6x|7x|8x|9x|10x)$/)) {
        info.size = cls;
      }

      if (cls === 'fa-spin') info.spin = true;
      if (cls === 'fa-pulse') info.pulse = true;

      if (cls === 'fa-flip-horizontal' || cls === 'fa-flip-h') info.flip = 'horizontal';
      if (cls === 'fa-flip-vertical' || cls === 'fa-flip-v') info.flip = 'vertical';

      if (cls === 'fa-rotate-90') info.rotate = 90;
      if (cls === 'fa-rotate-180') info.rotate = 180;
      if (cls === 'fa-rotate-270') info.rotate = 270;

      if (cls === 'fa-inverse') info.inverse = true;
      if (cls === 'fa-pull-left') info.pullLeft = true;
      if (cls === 'fa-pull-right') info.pullRight = true;
      if (cls === 'fa-border') info.border = true;
      if (cls === 'fa-fw' || cls === 'fa-fixed-width') info.fixedWidth = true;
      if (cls === 'fa-li') info.listItem = true;
    }

    return info;
  }

  function createSVGIcon(iconInfo, originalClasses) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    
    let svgClasses = ['fa-icon'];
    
    if (iconInfo.size) svgClasses.push(iconInfo.size);
    if (iconInfo.spin) svgClasses.push('fa-spin');
    if (iconInfo.pulse) svgClasses.push('fa-pulse');
    if (iconInfo.flip === 'horizontal') svgClasses.push('fa-flip-horizontal');
    if (iconInfo.flip === 'vertical') svgClasses.push('fa-flip-vertical');
    if (iconInfo.rotate > 0) svgClasses.push(`fa-rotate-${iconInfo.rotate}`);
    if (iconInfo.inverse) svgClasses.push('fa-inverse');
    if (iconInfo.pullLeft) svgClasses.push('fa-pull-left');
    if (iconInfo.pullRight) svgClasses.push('fa-pull-right');
    if (iconInfo.border) svgClasses.push('fa-border');
    if (iconInfo.fixedWidth) svgClasses.push('fa-fw');
    if (iconInfo.listItem) svgClasses.push('fa-li');

    const customClasses = originalClasses
      .split(' ')
      .filter(c => !c.startsWith('fa') && !c.startsWith('fa-'));
    svgClasses.push(...customClasses);

    svg.setAttribute('class', svgClasses.join(' '));
    svg.setAttribute('aria-hidden', 'true');

    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    const symbolId = `icon-${iconInfo.style}-${iconInfo.name}`;
    use.setAttributeNS('http://www.w3.org/1999/xlink', 'href', `#${symbolId}`);
    
    svg.appendChild(use);

    return svg;
  }
})();
