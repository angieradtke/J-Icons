<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.jicon
 * @copyright   (C) 2026 Angie Radtke
 * @license     GNU/GPL
 */

namespace Joomla\Plugin\System\JIcon\Field;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\CheckboxesField;

defined('_JEXEC') or die;

final class IconsField extends CheckboxesField
{
	protected $type = 'icons';
	
	/**
	 * Basis-Pfad zu den mitgelieferten Icons im Plugin-Media-Ordner.
	 */
	private const ICON_BASE = '/plugins/system/jicon/media/icons';
	
	/**
	 * Wichtige Icons. Sie werden oben gruppiert und bei leerer Auswahl
	 * automatisch vorselektiert.
	 *
	 * @var string[]
	 */
	private array $importantIcons = [
		'solid/house',
		'solid/search',
		'solid/user',
		'solid/gear',
		'solid/heart',
		'solid/star',
		'solid/check',
		'solid/times',
		'solid/arrow-right',
		'solid/arrow-left',
		'solid/bars',
		'solid/bell',
		'solid/envelope',
		'solid/download',
		'solid/upload',
		'solid/trash',
		'solid/edit',
		'solid/folder',
		'solid/calendar',
		'solid/circle-info',
		'brands/facebook',
		'brands/x-twitter',
		'brands/linkedin',
		'brands/github',
		'brands/joomla',
	];
	
	/**
	 * Icons aus dem Plugin-Media-Ordner einlesen, gruppiert nach Stil.
	 */
	public function getOptions()
	{
		$iconPath = JPATH_SITE . self::ICON_BASE;
		$styles   = ['solid', 'regular', 'brands'];
		$options  = [];
		
		foreach ($styles as $style) {
			$stylePath = $iconPath . '/' . $style;
			
			if (!is_dir($stylePath)) {
				continue;
			}
			
			$styleIcons = [];
			
			foreach (scandir($stylePath) as $file) {
				if (pathinfo($file, PATHINFO_EXTENSION) !== 'svg') {
					continue;
				}
				
				$iconName = pathinfo($file, PATHINFO_FILENAME);
				
				$styleIcons[] = [
					'value' => $style . '/' . $iconName,
					'text'  => $iconName,
					'icon'  => $stylePath . '/' . $file,
				];
			}
			
			usort($styleIcons, static fn ($a, $b) => strcmp($a['text'], $b['text']));
			
			$options[] = [
				'value'   => $style,
				'text'    => ucfirst($style),
				'options' => $styleIcons,
			];
		}
		
		return $options;
	}
	
	/**
	 * Gespeicherte Werte laden und normalisieren.
	 * Akzeptiert: JSON, komma-getrennte Strings, oder Arrays
	 */
	public function getValue($data, $group, $repeat)
	{
		$value = parent::getValue($data, $group, $repeat);
		
		// Wenn leer und kein Wert in $this->value, dann wichtige Icons vorselektieren
		if (empty($value) && empty($this->value)) {
			return json_encode($this->importantIcons);
		}
		
		// Wert normalisieren und als JSON speichern
		if (is_string($value) && $value !== '') {
			// Bereits JSON?
			$decoded = json_decode($value, true);
			if (is_array($decoded)) {
				return $value; // Bereits korrekt formatiert
			}
			
			// Komma-getrennt? Zu JSON konvertieren
			$icons = array_map('trim', explode(',', $value));
			$icons = array_filter($icons, static fn ($v) => $v !== '' && $v !== null);
			return json_encode(array_values($icons));
		}
		
		// Array? Zu JSON konvertieren
		if (is_array($value)) {
			$value = array_filter($value, static fn ($v) => $v !== '' && $v !== null);
			return json_encode(array_values($value));
		}
		
		return '';
	}
	
	/**
	 * Eigenen Picker rendern. Wichtig: Es werden eigene name[]-Checkboxen
	 * ausgegeben, deshalb braucht das Feld kein multiple-Attribut.
	 */
	public function getInput()
	{
		$groups = $this->getOptions();
		
		// Gespeicherte Auswahl normalisieren.
		$selected = $this->value;
		
		if (is_string($selected) && $selected !== '') {
			// Versuchen als JSON zu parsen
			$decoded = json_decode($selected, true);
			if (is_array($decoded)) {
				$selected = $decoded;
			} else {
				// Fallback: komma-getrennt
				$selected = array_map('trim', explode(',', $selected));
			}
		}
		
		$selected = (array) $selected;
		$selected = array_filter($selected, static fn ($v) => $v !== '' && $v !== null);
		
		// Noch nichts gespeichert? Dann wichtige Icons vorselektieren.
		if ($selected === []) {
			$selected = $this->importantIcons;
		}
		
		$doc = Factory::getApplication()->getDocument();
		$doc->addStyleSheet('plugins/system/jicon/media/css/icon-picker.min.css');
		$doc->addScript('plugins/system/jicon/media/js/icon-picker.js');
		
		$html  = '<div class="jicon-picker">';
		$html .= '<div class="jicon-search">';
		$html .= '<input type="text" class="form-control jicon-search-input" placeholder="Icons filtern..." />';
		$html .= '</div>';
		$html .= '<div class="jicon-container">';
		
		// Empfohlene Icons als erste Gruppe.
		$important = [];
		
		foreach ($groups as $group) {
			foreach ($group['options'] as $icon) {
				if (in_array($icon['value'], $this->importantIcons, true)) {
					$important[] = $icon;
				}
			}
		}
		
		if ($important !== []) {
			$html .= $this->renderGroup('Empfohlene Icons', $important, $selected);
		}
		
		// Alle Stile.
		foreach ($groups as $group) {
			$html .= $this->renderGroup($group['text'], $group['options'], $selected);
		}
		
		$html .= '</div>';
		$html .= '</div>';
		
		return $html;
	}
	
	/**
	 * Eine Icon-Gruppe als Grid rendern.
	 *
	 * @param  string  $label     Gruppenname
	 * @param  array   $icons     Liste von Icon-Definitionen
	 * @param  array   $selected  Aktuell ausgewaehlte Werte
	 */
	private function renderGroup(string $label, array $icons, array $selected): string
	{
		$html  = '<fieldset class="jicon-group">';
		$html .= '<legend>' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</legend>';
		$html .= '<div class="jicon-grid" style="display:flex; gap:24px; flex-wrap:wrap">';
		
		foreach ($icons as $icon) {
			$value   = (string) $icon['value'];
			$text    = (string) $icon['text'];
			$checked = in_array($value, $selected, true) ? ' checked' : '';
			$svg     = '';
			
			if (!empty($icon['icon']) && is_file($icon['icon'])) {
				$raw = file_get_contents($icon['icon']);
				
				if ($raw !== false && preg_match('/<svg[^>]*>.*?<\/svg>/is', $raw, $m)) {
					$svg = $m[0];
				}
			}
			
			$html .= '<label class="jicon-option" style="flex: 1 1 3em; border:solid 1px #ddd;padding:24px">';
			if ($svg !== '') {
				$html .= '<span class="jicon-preview" >' . $svg . '</span>';
			}
			
			$html .= '<span class="jicon-label">' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</span>';
			$html .= '<input type="checkbox" name="' . htmlspecialchars($this->name, ENT_QUOTES, 'UTF-8') . '[]" value="'
				. htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"' . $checked
				. ' class="jicon-checkbox" />';
			$html .= '</label>';
		}
		
		$html .= '</div>';
		$html .= '</fieldset>';
		
		return $html;
	}
}
