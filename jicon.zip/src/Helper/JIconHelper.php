<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.jicon
 * @copyright   (C) 2026 Angie Radtke
 * @license     GNU/GPL
 */

namespace Joomla\Plugin\System\JIcon\Helper;

use Joomla\Registry\Registry;

defined('_JEXEC') or die;

final class JIconHelper
{
    private array $icons = [];
    private ?string $spriteCache = null;
    private string $iconPath;
    private Registry $config;

    public function __construct(Registry $config)
    {
        $this->config = $config;
        $this->iconPath = JPATH_SITE . '/' . 
            $config->get('icon_path', 'plugins/system/jicon/media/icons');
    }

    /**
     * Register single icon
     */
    public function register(string $name, string $style = 'solid'): self
    {
        $key = "{$style}/{$name}";
        if (!in_array($key, $this->icons)) {
            $this->icons[] = $key;
        }
        return $this;
    }

    /**
     * Register multiple icons
     */
    public function registerMultiple(array $names, string $style = 'solid'): self
    {
        foreach ($names as $name) {
            $this->register($name, $style);
        }
        return $this;
    }

    /**
     * Get all registered icons
     */
    public function getRegistered(): array
    {
        return $this->icons;
    }

    /**
     * Generate sprite with only registered icons
     */
    public function getSprite(): string
    {
        if ($this->spriteCache !== null) {
            return $this->spriteCache;
        }

        $svg = '<svg style="display: none;" id="j-icon-sprite" xmlns="http://www.w3.org/2000/svg">' . "\n";

        foreach ($this->icons as $icon) {
            if (strpos($icon, '/') === false) {
                continue;
            }
            
            [$style, $name] = explode('/', $icon);
            $file = $this->iconPath . '/' . $style . '/' . $name . '.svg';

            if (file_exists($file)) {
                $content = file_get_contents($file);
                $symbolId = str_replace(['/', '.svg'], ['-', ''], $icon);
                $svg .= $this->svgToSymbol($content, $symbolId);
                $svg .= "\n";
            }
        }

        $svg .= '</svg>';
        $this->spriteCache = $svg;

        return $svg;
    }

    /**
     * Convert SVG to Symbol element
     */
    private function svgToSymbol(string $svgContent, string $id): string
    {
        // Extract viewBox
        if (preg_match('/viewBox="([^"]*)"/', $svgContent, $matches)) {
            $viewBox = $matches[1];
        } else {
            $viewBox = '0 0 512 512';
        }

        // Extract path
        if (preg_match('/<path\s+([^>]*)>/i', $svgContent, $matches)) {
            $pathAttrs = $matches[1];
        } else {
            return '<!-- Icon not found: ' . htmlspecialchars($id) . ' -->';
        }

        return '<symbol id="icon-' . htmlspecialchars($id) . '" viewBox="' 
            . htmlspecialchars($viewBox) . '">'
            . '<path ' . $pathAttrs . '/>'
            . '</symbol>';
    }

    /**
     * Render icon
     */
    public function render(
        string $name,
        string $style = 'solid',
        string $classes = ''
    ): string {
        $this->register($name, $style);
        $symbolId = str_replace(['/', '.svg'], ['-', ''], "{$style}/{$name}");
        $classList = 'j-icon ' . trim($classes);

        return '<svg class="' . htmlspecialchars($classList) . '" aria-hidden="true">'
            . '<use href="#icon-' . htmlspecialchars($symbolId) . '"></use>'
            . '</svg>';
    }
}
