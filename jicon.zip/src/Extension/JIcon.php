<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.jicon
 * @copyright   (C) 2026 Angie Radtke
 * @license     GNU/GPL
 */

namespace Joomla\Plugin\System\JIcon\Extension;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\DispatcherAwareInterface;
use Joomla\Event\DispatcherAwareTrait;
use Joomla\Event\SubscriberInterface;
use Joomla\Plugin\System\JIcon\Helper\JIconHelper;
use Joomla\Plugin\System\JIcon\Service\JIconService;

defined('_JEXEC') or die;

final class JIcon extends CMSPlugin implements SubscriberInterface, DispatcherAwareInterface
{
    use DispatcherAwareTrait;

    private JIconHelper $helper;
    private JIconService $service;

    /**
     * Return subscribed events
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onBeforeRender'  => 'onBeforeRender',
            'onAfterRender'   => 'onAfterRender',
        ];
    }

    /**
     * Set helper instance
     */
    public function setHelper(JIconHelper $helper): void
    {
        $this->helper = $helper;
    }

    /**
     * Set service instance
     */
    public function setService(JIconService $service): void
    {
        $this->service = $service;
    }

    /**
     * Before render - load assets
     */
    public function onBeforeRender(): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        $app = $this->getApplication();
        $document = $app->getDocument();

        $mediaPath = 'plugins/system/jicon/media';

        // Load j-icon base stylesheet
        $document->addStyleSheet($mediaPath . '/css/j-icon.min.css');

        // Load BC FontAwesome assets if enabled
        if ($this->params->get('enable_bc_fontawesome', 0)) {
            $document->addStyleSheet($mediaPath . '/css/bc-fontawesome.min.css');
            $document->addScript($mediaPath . '/js/bc-fontawesome.js', [], ['type' => 'module']);
        }

        // Custom color CSS
        $css = $this->service->getCustomColorCSS($this->params);
        $document->addStyleDeclaration($css);
    }

    /**
     * After render - inject sprite
     */
    public function onAfterRender(): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        $position = $this->params->get('inject_position', 'body_start');
        if ($position === 'manual') {
            return;
        }

        // Selektierte Icons einlesen und auf eine flache Liste von Strings normalisieren
        $selectedIcons = $this->normalizeIconList($this->params->get('selected_icons', []));

        foreach ($selectedIcons as $icon) {
            if (!str_contains($icon, '/')) {
                continue;
            }

            [$style, $name] = explode('/', $icon, 2);

            if ($style !== '' && $name !== '') {
                $this->helper->register($name, $style);
            }
        }

        $app    = $this->getApplication();
        $body   = $app->getBody();
        $sprite = $this->helper->getSprite();

        if (!is_string($body) || $sprite === '') {
            return;
        }

        if ($position === 'body_start') {
            $body = str_replace('<body>', '<body>' . $sprite, $body);
        } else {
            $body = str_replace('</body>', $sprite . '</body>', $body);
        }

        $app->setBody($body);
    }

    /**
     * Wert aus den Plugin-Parametern in eine flache Liste von Icon-Strings
     * umwandeln. Akzeptiert Arrays, Objekte, JSON-Strings und kommagetrennte
     * Strings und ignoriert alles, was kein nutzbarer String ist.
     *
     * @param  mixed  $value  Rohwert aus den Parametern
     * @return string[]
     */
    private function normalizeIconList($value): array
    {
        if (is_string($value)) {
            $value = trim($value);

            if ($value === '') {
                return [];
            }

            $decoded = json_decode($value, true);
            $value   = is_array($decoded) ? $decoded : explode(',', $value);
        } elseif (is_object($value)) {
            $value = (array) $value;
        } elseif (!is_array($value)) {
            return [];
        }

        $result = [];

        array_walk_recursive($value, static function ($item) use (&$result) {
            if (is_string($item)) {
                $item = trim($item);

                if ($item !== '') {
                    $result[] = $item;
                }
            }
        });

        return $result;
    }

    /**
     * Public render method for global function
     */
    public function renderIcon(string $name, string $style = 'solid', string $classes = ''): string
    {
        return $this->helper->render($name, $style, $classes);
    }

    /**
     * Check if plugin is enabled
     */
    private function isEnabled(): bool
    {
        return (bool) $this->params->get('enable_plugin', 1);
    }
}
